import QrCode from './qrcode';

export default QrCode;
